//
// Created by kamotora on 31.03.2021.
//

#include "Lab3.h"
