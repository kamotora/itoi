#include <QApplication>
#include <QPushButton>
#include <QLabel>
#include "test/Lab3.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    Lab3::test();
    return 0;
}
