//
// Created by kamotora on 25.02.2021.
//

#include "Lab2.h"
